import 'package:flutter/material.dart';

class PanelCenterPage extends StatefulWidget {


  @override
  State<PanelCenterPage> createState() => _PanelCenterPageState();
}

class _PanelCenterPageState extends State<PanelCenterPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(backgroundColor:Colors.red,),
    );
  }
}